package com.miath.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackgroundColor(Color.rgb(18, 18, 24));

        TextView logo = new TextView(this);
        logo.setText("MIATH");
        logo.setTextSize(42);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        logo.setTextColor(Color.rgb(65, 255, 120));
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("TON ESPACE, TES IDÉES");
        subtitle.setTextSize(14);
        subtitle.setTypeface(Typeface.DEFAULT_BOLD);
        subtitle.setTextColor(Color.WHITE);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(12);
        root.addView(subtitle, subtitleParams);

        TextView message = new TextView(this);
        message.setText("Bienvenue dans MIATH\n\nLa base de ton application est prête. Les prochaines fonctions pourront être ajoutées ici.");
        message.setTextSize(17);
        message.setTextColor(Color.rgb(220, 220, 228));
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams messageParams = new LinearLayout.LayoutParams(-1, -2);
        messageParams.topMargin = dp(34);
        root.addView(message, messageParams);

        TextView status = new TextView(this);
        status.setText("VERSION 1.0");
        status.setTextSize(12);
        status.setTextColor(Color.rgb(65, 255, 120));
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(36);
        root.addView(status, statusParams);

        setContentView(root);
    }
}
