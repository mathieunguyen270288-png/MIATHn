# MIATH

Projet Android de démarrage pour l'application MIATH.

## Construire l'APK depuis GitHub (sans ordinateur)

1. Envoyez **tous les fichiers de ce dossier** dans votre dépôt GitHub `MIATH`, en conservant les dossiers.
2. Ouvrez l'onglet **Actions** du dépôt.
3. Choisissez le workflow **Build MIATH APK** puis appuyez sur **Run workflow** si le lancement automatique ne démarre pas.
4. Attendez que le workflow soit terminé en vert.
5. Ouvrez le résultat du workflow et téléchargez l'élément **MIATH-debug-apk**.
6. Sur le téléphone, ouvrez le ZIP téléchargé et récupérez `app-debug.apk`, puis ouvrez-le pour l'installer.

> C'est un projet de base fonctionnel qui affiche l'écran d'accueil MIATH. Il ne s'agit pas encore d'une application complète avec toutes les fonctions imaginées.
